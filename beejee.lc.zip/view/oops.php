<!doctype html>
<html lang="ru">
<? 
include_once "header.php";
?>
<div id="appCapsule">
<div class="error-page">
<h1 class="title">Страница не найдена</h1>
<div class="text mb-5">
Код ошибки: 404
</div>
<div class="fixed-footer">
<div class="row">
<div class="col-12">
<a href="/" class="btn bg-black btn-lg btn-block">ГЛАВНАЯ СТРАНИЦА</a>
</div>
</div>
</div>
</div>
</div>
<? 
include_once "footer.php";
?>
</body>
</html>