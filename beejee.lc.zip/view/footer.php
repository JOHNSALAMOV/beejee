<script src="<?php echo $settings['url']; ?>view/assets/js/lib/jquery-3.4.1.min.js"></script>
<script src="<?php echo $settings['url']; ?>view/assets/js/lib/bootstrap.min.js" async></script>
<script src="<?php echo $settings['url']; ?>view/assets/js/base.js"></script>